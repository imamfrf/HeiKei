package com.raion.android.heikei;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CategoryActivity extends AppCompatActivity implements View.OnClickListener {
    public static String category;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        Button bt_vege = (Button) findViewById(R.id.bt_vege);
        Button bt_anak = (Button) findViewById(R.id.bt_anak);
        Button bt_hamil = (Button) findViewById(R.id.bt_hamil);
        Button bt_diet = (Button) findViewById(R.id.bt_diet);
        Button bt_sekali = (Button) findViewById(R.id.bt_sekali);
        //TextView textView = (TextView) findViewById(R.id.textView);

        bt_vege.setOnClickListener(this);
        bt_anak.setOnClickListener(this);
        bt_hamil.setOnClickListener(this);
        bt_diet.setOnClickListener(this);
        bt_sekali.setOnClickListener(this);
    }

    public void setCategory(String category){
        this.category = category;
    }

    public String getCategory() {
        return category;
    }

    @Override
    public void onClick(View view) {
        Button b = (Button)view;
        setCategory(b.getText().toString());
        AlertDialog alertDialog = new AlertDialog.Builder(CategoryActivity.this).create();
        alertDialog.setTitle("Login Gagal!");
        alertDialog.setMessage(getCategory());
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        //alertDialog.show();
        Intent selectCate = new Intent(CategoryActivity.this, SelectCateActivity.class);
        startActivity(selectCate);
    }
}
